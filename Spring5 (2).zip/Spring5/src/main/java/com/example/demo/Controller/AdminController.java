package com.example.demo.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Admin;
import com.example.demo.Repository.AdminRepository;
import com.example.demo.exception.ResourceNotFoundException;

@RestController

public class AdminController {
	
	public class CertificateController {
		@Autowired
		AdminRepository repository;
		@PostMapping("admin")
		public Admin createAdmin(@RequestBody Admin admin) {
			return repository.save(admin);
		}
		@GetMapping("/admin")
		public List<Admin> getAllAdmin(){
			return repository.findAll();
		}	
		@GetMapping("/admin/{id}")
		public ResponseEntity<Admin> getCertificateById(@PathVariable Long id) {
			Admin admin= repository.findById(id)
					.orElseThrow(() -> new ResourceNotFoundException("Admin is not available with id :" + id));
			return ResponseEntity.ok(admin);
		}
		@PutMapping("/admin/{id}")
		public ResponseEntity<Admin> updateAdmin(@PathVariable Long id, @RequestBody Admin adminDetails){
			Admin admin = repository.findById(id)
					.orElseThrow(() -> new ResourceNotFoundException("Admin is not available with id :" + id));
			
			admin.setName(adminDetails.getName());
			admin.setPassword(adminDetails.getPassword());
			
			
			Admin updatedAdmin = repository.save(admin);
			return ResponseEntity.ok(updatedAdmin);
		}
		@DeleteMapping("/admin/{id}")
		public ResponseEntity<Map<String, Boolean>> deleteAdmin(@PathVariable Long id){
			Admin admin = repository.findById(id)
					.orElseThrow(() -> new ResourceNotFoundException("Admin is not available with id :" + id));
			
			repository.delete(admin);
			Map<String, Boolean> response = new HashMap<>();
			response.put("deleted", Boolean.TRUE);
			return ResponseEntity.ok(response);
		}
	}

}
	