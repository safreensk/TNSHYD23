package program1;

public class A {
	int b=40;
	static int c=30;
	

	public static void main(String[] args) {
		int a=20;
		System.out.println("a");
		A a1 = new A();
		System.out.println("a1.b");
		System.out.println("A.c");
	
	
	}

}

