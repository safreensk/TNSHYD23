package program1;

public class B {int b=20;
static int c=30;
class C{
	  int a=10;
}
public static void main(String[] args) {
		System.out.println("a");
		B b1 =new B();
		System.out.println("b1.b");
		System.out.println("B.c");

	}

}


