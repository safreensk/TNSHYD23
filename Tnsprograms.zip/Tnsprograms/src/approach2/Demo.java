package approach2;

public class Demo {
	int b=20;
	static int c=30;
	int display()
	{
		return 20;
	}
        static void space() {
        	System.out.println("10");
        }
        class C
        {
	public static void main(String[] args) {
		Demo b1 =new Demo();
		System.out.println("b1.b");
		b1.display();
		System.out.println("Demo.C");
		Demo.space();
	}
		// TODO Auto-generated method stub

	}

}



