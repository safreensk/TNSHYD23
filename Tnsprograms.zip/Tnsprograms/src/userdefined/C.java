package userdefined;

import userdefined.C;

public class C {
	private void display() {
		System.out.println("Welcome to hyderabad");
		}

public static void main(String[] args) {
	C obj = new C();
	obj.display();
	
		}
}



