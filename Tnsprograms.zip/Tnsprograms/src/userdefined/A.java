package userdefined;

public class A {
	public void display() {
		System.out.println("Userdefined");
	}

}



