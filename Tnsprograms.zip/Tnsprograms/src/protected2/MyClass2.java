package protected2;

import protected1.MyClass1;

public class MyClass2 {

		   public static void main(String[] args) {
			   MyClass1 obj = new MyClass1();
			   obj.display();
				// TODO Auto-generated method stub

			}

		}



