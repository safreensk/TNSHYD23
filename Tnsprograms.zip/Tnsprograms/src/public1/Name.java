package public1;

public class Name {
	public void display()
	{
		System.out.println("Welcome to sri indu college of enginnering and technology");
	}
	}




