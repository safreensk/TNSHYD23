package userdefined2;

import userdefined.A;

public class B {
	public static void main(String[] args) {
		A obj=new A();
		obj.display();
		// TODO Auto-generated method stub

	}

}

