package public2;

import public1.Name;

public class Safreen {

		public static void main(String[] args) {
			Name obj = new Name();
			obj.display();
			


}
}
