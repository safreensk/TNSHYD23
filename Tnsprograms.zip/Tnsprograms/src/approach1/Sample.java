package approach1;

public class Sample {
	int b = 60;
	static int c = 40;
	int display() {
		return 20;
		}
	static void name() {
	System.out.println("20");
}
	public static void main(String[] args) {
		Sample a1 = new Sample();
		System.out.println("a1.b");
		System.out.println("Sample.c");
		System.out.println("c");
		a1.display();
		Sample.name();

	}

}

