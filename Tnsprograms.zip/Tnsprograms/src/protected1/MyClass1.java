package protected1;

public class MyClass1 {
	public void display() {
		System.out.println("welcome to sri indu college");
	
	}
}



